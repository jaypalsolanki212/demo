<?php
$hostname="localhost";
$username="root";
$password="";
$databasename="cod";

$cn = new mysqli($hostname, $u_Name, $pass,$databasename);

//$cn = mysql_connect($hostname, $username, $password);
//mysql_select_db($cn,$databasename);
?>